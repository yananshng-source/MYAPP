# -*- coding: utf-8 -*-
from flask import Flask, request, jsonify, send_file, render_template
import pandas as pd
from io import StringIO, BytesIO
import requests
from bs4 import BeautifulSoup
import threading
import time
import traceback

app = Flask(__name__)

tasks = {}

# 清理 DataFrame
def clean_df(df, group_cols=None):
    if group_cols:
        fill_cols = [col for col in group_cols if col in df.columns]
        if fill_cols:
            df[fill_cols] = df[fill_cols].ffill()
    df = df.apply(lambda col: col.map(lambda x: str(x).strip() if pd.notna(x) else x))
    return df

# 抓取函数
def scrape_urls(url_list, group_cols=None, progress_callback=None):
    sheet_data = {}
    all_data = []

    total = len(url_list)
    for i, url in enumerate(url_list):
        try:
            if progress_callback:
                progress_callback(i, total, f"正在抓取: {url}")

            headers = {"User-Agent": "Mozilla/5.0"}
            r = requests.get(url, headers=headers, timeout=10)
            r.encoding = r.apparent_encoding
            soup = BeautifulSoup(r.text, "html.parser")

            title_tag = soup.find("title")
            title = title_tag.string.strip() if title_tag else "未命名网页"
            safe_title = "".join([c if c not in r'\/:*?"<>|' else "_" for c in title])

            table = soup.find("table")
            if table:
                dfs = pd.read_html(StringIO(str(table)), header=0)
                df = dfs[0]
                df = clean_df(df, group_cols=group_cols)
                sheet_data[safe_title] = df
                all_data.append(df)
        except Exception as e:
            print(f"抓取失败 {url}: {str(e)}")
            continue

    return sheet_data, all_data

# 首页
@app.route('/')
def index():
    return render_template('index.html')

# 抓取任务
@app.route('/scrape', methods=['POST'])
def scrape():
    try:
        data = request.get_json(force=True)
        urls = [u.strip() for u in data.get('urls', []) if u.strip()]
        group_cols = [c.strip() for c in data.get('group_cols', []) if c.strip()]

        if not urls:
            return jsonify({'error': '请输入至少一个URL'}), 400

        task_id = str(int(time.time() * 1000))
        tasks[task_id] = {'status': 'running', 'progress': 0, 'message': '任务已开始'}

        def update_progress(current, total, message):
            tasks[task_id]['progress'] = int((current / total) * 100)
            tasks[task_id]['message'] = message

        def run_task():
            try:
                sheet_data, all_data = scrape_urls(urls, group_cols=group_cols, progress_callback=update_progress)
                if sheet_data:
                    output = BytesIO()
                    with pd.ExcelWriter(output, engine='openpyxl') as writer:
                        for sheet_name, df in sheet_data.items():
                            df.to_excel(writer, sheet_name=sheet_name[:31], index=False)
                        if all_data:
                            combined_df = pd.concat(all_data, ignore_index=True)
                            combined_df = clean_df(combined_df, group_cols=group_cols)
                            combined_df.to_excel(writer, sheet_name='汇总', index=False)
                    output.seek(0)
                    tasks[task_id]['file_data'] = output.getvalue()
                    tasks[task_id]['status'] = 'completed'
                    tasks[task_id]['message'] = f'成功抓取 {len(sheet_data)} 个表格'
                else:
                    tasks[task_id]['status'] = 'error'
                    tasks[task_id]['message'] = '未找到任何表格数据'
            except Exception as e:
                tasks[task_id]['status'] = 'error'
                tasks[task_id]['message'] = f'处理错误: {str(e)}\n{traceback.format_exc()}'

        threading.Thread(target=run_task, daemon=True).start()
        return jsonify({'task_id': task_id, 'message': '任务已开始'})

    except Exception as e:
        return jsonify({'error': f'服务器错误: {str(e)}\n{traceback.format_exc()}'}), 500

# 查询进度（不返回 file_data）
@app.route('/progress/<task_id>')
def progress(task_id):
    try:
        task = tasks.get(task_id)
        if not task:
            return jsonify({'status': 'unknown', 'progress': 0, 'message': '任务不存在'})
        response = {k: v for k, v in task.items() if k != 'file_data'}
        return jsonify(response)
    except Exception as e:
        return jsonify({'status': 'error', 'progress': 0, 'message': f'查询进度异常: {str(e)}'}), 500

# 下载 Excel 文件
@app.route('/download/<task_id>')
def download(task_id):
    try:
        task = tasks.get(task_id)
        if task and task.get('file_data'):
            output = BytesIO(task['file_data'])
            return send_file(output,
                             as_attachment=True,
                             download_name='高校招生录取数据.xlsx',
                             mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
        return jsonify({'error': '文件不存在'}), 404
    except Exception as e:
        return jsonify({'error': f'下载异常: {str(e)}'}), 500

# 健康检查
@app.route('/health')
def health():
    return jsonify({'status': 'healthy'})

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
